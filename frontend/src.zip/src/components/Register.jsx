import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

export default function Register() {

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [contact, setContact] = useState('');
    const [password, setPassword] = useState('');
    const nav = useNavigate();

    const submitHandler = async (e) => {
        e.preventDefault();

        console.log({ name, email, password, contact });

        fetch("http://localhost:5000/api/email/regisration", {
            method: "POST",
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify({
                name,
                email,
                password,
                contact
            })
        })
            .then(res => res.json())
            .then(result => {
                console.log(result);
                if (result.success) {
                    toast.success(result.message || "Registered successfully!");
                    setTimeout(() => nav('/Login'), 2000);
                } else {
                    toast.error(result.message || "Something went wrong");
                }
                setTimeout(() => nav('/Login'), 1000);
            })
            .catch(err => {
                console.error(err);
                toast.error("Server error");
            });
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
            <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-lg">
                <h2 className="text-3xl font-bold mb-6 text-center text-blue-600">Register</h2>

                <form onSubmit={submitHandler} className="space-y-4">
                    <input
                        type="text"
                        placeholder="Full Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />

                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />

                    <input
                        type="tel"
                        placeholder="Contact Number"
                        value={contact}
                        onChange={(e) => setContact(e.target.value)}
                        className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />

                    <button
                        type="submit"
                        className="w-full py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-500 transition">
                        Register
                    </button>
                </form>
            </div>

            <ToastContainer position="top-center" autoClose={3000} />
        </div>
    );
}

import React from "react";
import ProductCard from "./ProductCard";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

export default function PromoSection() {
    return (
        <section>
            <div className="w-full min-h-screen bg-green-50 flex flex-col md:flex-row items-center justify-center px-6 py-12 gap-8">
                {/* LEFT SIDE */}
                <div className="flex-2 bg-purple-200 rounded-lg p-5 flex flex-col md:flex-row items-center md:items-start gap-8 shadow-md min-h-[620px]">
                    {/* Text */}
                    <div className="flex flex-col">
                        <span className="text-yellow-400 mt-[60px] text-[40px] mb-[20px] font-semibold mb-2 ">
                            100% Natural
                        </span>
                        <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-4">
                            Fresh Smoothie <br /> & Summer Juice
                        </h1>
                        <p className="text-gray-600 mb-6 max-w-md">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dignissim massa diam elementum.
                        </p>
                        <button className="border-2 border-green-700 text-green-700 px-6 py-3 rounded-full hover:bg-green-700 hover:text-white transition w-fit mb-[20px]">
                            SHOP NOW
                        </button>
                    </div>

                    {/* Smoothie Bottle */}
                    <div className="flex-shrink-0 flex justify-center items-center">
                        <img
                            src="https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_600/NI_CATALOG/IMAGES/CIW/2025/3/11/28c25363-4565-4f25-8a3b-2b1273743210_454359_1.png"
                            alt="Smoothie Bottle"
                            className="w-40 md:w-80 rotate-[30deg] mt-[100px] mx-[50px]"
                        />
                    </div>
                </div>


                {/* RIGHT SIDE */}
                <div className="flex-1 flex flex-col gap-8">
                    {/* Fruits & Veggies Card */}
                    <div className="flex justify-between items-center bg-red-100 rounded-lg p-6 shadow-md h-[290px] " style={{ backgroundColor: "" }}>
                        <div className="w-[500px]">
                            <p className="text-[30px] text-gray-700 mb-1">20% Off</p>
                            <h3 className="text-[40px] font-bold text-gray-700 mb-2">
                                Fruits & Vegetables
                            </h3>
                            <a href="#" className="text-gray-600 mt-[10px] text-[18px] hover:underline">
                                Shop Collection →
                            </a>
                        </div>
                        <img
                            src="http://4.bp.blogspot.com/-iCWLv2hDiXM/UM6yuDEIsQI/AAAAAAAAAHk/v2IFZwwqxUE/s1600/Fruits+and+Vegetables+(1).jpg"
                            alt="Fruits and Vegetables"
                            className="w-45 h-46 object-cover rounded-[100px] mt-[0px]"
                        />
                    </div>

                    {/* Baked Products Card */}
                    <div className="flex justify-between items-center bg-teal-200 rounded-lg p-6 shadow-md h-[290px]">
                        <div>
                            <p className="text-[30px] text-gray-700 mb-1">15% Off</p>
                            <h3 className="text-[40px] font-bold text-gray-700 mb-2">
                                Baked Products
                            </h3>
                            <a href="#" className="text-gray-600 mt-[10px] text-[18px] hover:underline">
                                Shop Collection →
                            </a>
                        </div>
                        <img
                            src="https://thumbs.dreamstime.com/b/baked-goods-28485020.jpg"
                            alt="Baked Products"
                            className="w-45 h-46 object-cover rounded-[100px]  rotate-[30deg]"
                        />
                    </div>
                </div>
            </div>
            {/* second sec.................   */}

            <div className="h-[350px] bg-red-50">
                <div className="max-w-screen-7xl mx-auto px-8 py-12">
                    {/* Header */}
                    <div className="flex justify-between items-center mb-8">
                        <h2 className="text-3xl font-bold text-gray-800">Category</h2>
                        <a
                            href="#"
                            className="text-base text-gray-500 hover:text-green-600 transition"
                        >
                            View All Categories →
                        </a>
                    </div>

                    {/* Swiper */}
                    <Swiper
                        modules={[Navigation]}
                        navigation
                        spaceBetween={10}
                        slidesPerView={2}
                        breakpoints={{
                            640: { slidesPerView: 3 },
                            768: { slidesPerView: 4 },
                            1024: { slidesPerView: 6 },
                        }}
                        className="pb-8"
                    >
                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-0 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                                        alt="Fruits"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Fruits
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-50 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://kidlingoo.com/wp-content/uploads/vegetables_name_in_english_50.jpg"
                                        alt="Vegetables"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Vegetables
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-50 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://www.wallpics.net/wp-content/uploads/2018/07/Fast-Food-Photos.jpg"
                                        alt="Baked"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Baked
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-50 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://tse4.mm.bing.net/th/id/OIP.53yAU2iJ5ZSKQwykODu0uAHaEJ?pid=Api&P=0&h=220"
                                        alt="Sweets"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Sweets
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-50 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://wallpaperaccess.com/full/3410682.jpg"
                                        alt="Drinks"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Drinks
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-50 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://kidlingoo.com/wp-content/uploads/vegetables_name_in_english_50.jpg"
                                        alt="Vegetables"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Vegetables
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transform hover:scale-105 transition-all duration-500 hover:bg-green-50 group">
                                <div className="overflow-hidden">
                                    <img
                                        src="https://www.wallpics.net/wp-content/uploads/2018/07/Fast-Food-Photos.jpg"
                                        alt="Baked"
                                        className="w-full h-28 object-cover transition-transform duration-500 group-hover:scale-110"
                                    />
                                </div>
                                <div className="p-4">
                                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                                        Baked
                                    </h3>
                                </div>
                            </div>
                        </SwiperSlide>
                    </Swiper>
                </div>
            </div>


            {/* third section .......  */}



            <div className="h-[350px] bg-red-50">
                <div className="max-w-screen-7xl mx-auto px-8 py-12">
                    {/* Header */}
                    <div className="flex justify-between items-center mb-8">
                        <h2 className="text-3xl font-bold text-gray-800">
                            Newly Arrived Brands
                        </h2>
                        <a
                            href="#"
                            className="text-base text-gray-500 hover:text-green-600 transition"
                        >
                            View All →
                        </a>
                    </div>

                    {/* Swiper */}
                    <Swiper
                        modules={[Navigation]}
                        navigation
                        spaceBetween={24}
                        slidesPerView={1}
                        breakpoints={{
                            640: { slidesPerView: 2 },
                            768: { slidesPerView: 3 },
                            1024: { slidesPerView: 4 },
                        }}
                        className="pb-8"
                    >
                        {/* CARD 1 */}
                        <SwiperSlide>
                            <div className="flex justify-between items-center w-[300px] bg-white pt-3 rounded-lg p-6 shadow-md h-[150px] transition-all duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                                <img
                                    src="https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_600/19a39b296963f02f6a8682cd6bfce048"
                                    alt="Dabur Honey"
                                    className="w-22 h-25 object-cover rounded-lg"
                                />
                                <div className="mx-4">
                                    <p className="text-xl text-gray-700 mb-1">Dabur Honey</p>
                                    <h4 className="text-[16px] font-bold text-gray-700">
                                        Pure and Natural honey for health and sweetness
                                    </h4>
                                </div>
                            </div>
                        </SwiperSlide>

                        {/* CARD 2 */}
                        <SwiperSlide>
                            <div className="flex justify-between items-center w-[300px] bg-white pt-3 rounded-lg p-6 shadow-md h-[150px] transition-all duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                                <img
                                    src="https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_600/NI_CATALOG/IMAGES/CIW/2024/3/15/9303c928-3aef-417b-b16f-532404d5cd7b_coffee_CHKX9TDI3C_MN.png"
                                    alt="Bevzila Coffee"
                                    className="w-22 h-25 object-cover rounded-lg"
                                />
                                <div className="mx-4">
                                    <p className="text-xl text-gray-700 mb-1">Bevzila Coffee</p>
                                    <h4 className="text-[16px] font-bold text-gray-700">
                                        Bevzila Turkish hazelnut Flavoured Coffee
                                    </h4>
                                </div>
                            </div>
                        </SwiperSlide>

                        {/* CARD 3 */}
                        <SwiperSlide>
                            <div className="flex justify-between items-center w-[300px] bg-white pt-3 rounded-lg p-6 shadow-md h-[150px] transition-all duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                                <img
                                    src="https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_600/NI_CATALOG/IMAGES/CIW/2025/1/11/ae752d73-263b-4958-9f3f-9c2e011546c5_259749_1.png"
                                    alt="Moms Magic"
                                    className="w-22 h-25 object-cover rounded-lg"
                                />
                                <div className="mx-4">
                                    <p className="text-xl text-gray-700 mb-1">Moms Magic</p>
                                    <h4 className="text-[16px] font-bold text-gray-700">
                                        Sunfeast Mom's Magic Rich Butter Biscuits
                                    </h4>
                                </div>
                            </div>
                        </SwiperSlide>

                        {/* CARD 4 */}
                        <SwiperSlide>
                            <div className="flex justify-between items-center w-[300px] bg-white pt-3 rounded-lg p-6 shadow-md h-[150px] transition-all duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                                <img
                                    src="https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_600/NI_CATALOG/IMAGES/CIW/2025/3/15/06a89b71-9e9b-4c37-912b-923bef9ad2fc_15751_1.png"
                                    alt="Cashew"
                                    className="w-22 h-25 object-cover rounded-lg"
                                />
                                <div className="mx-4">
                                    <p className="text-xl text-gray-700 mb-1">Cashew</p>
                                    <h4 className="text-[16px] font-bold text-gray-700">
                                        Supreme Harvest Good Quality Cashews
                                    </h4>
                                </div>
                            </div>
                        </SwiperSlide>
                    </Swiper>
                </div>
            </div>



            {/* fourth Page ............... */}
            <h2 className="text-3xl mt-8 mx-6 font-bold text-gray-800">Tranding Products </h2>
            <div className='max-w-9xl mx-auto px-4 py-8 flex flex-row flex-wrap items-start gap-6'>
                <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
 <div>
                    <div className="max-w-sm rounded-lg overflow-hidden shadow-lg bg-white p-4">

                        {/* Product Image with Discount and Favorite */}
                        <div className="relative">
                            <img
                                className="w-full h-48 object-cover rounded-md"
                                src="https://themewagon.github.io/FoodMart/images/thumb-milk.png"
                                alt="Sunstar Fresh Melon Juice"
                            />
                            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -30%
                            </div>
                            <button className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-md transition-all duration-300 hover:bg-red-300 hover:shadow-lg">
                                <svg
                                    className="w-5 h-5 text-gray-500 hover:text-red-500 transition-colors duration-300"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
           2 5.42 4.42 3 7.5 3c1.74 0 3.41 1.01 4.5 2.09C13.09 4.01
           14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55
           11.54L12 21.35z"
                                    />
                                </svg>
                            </button>
                        </div>

                        {/* Product Info */}
                        <div className="mt-4">
                            <h3 className="font-bold text-lg text-gray-800 mb-1">Sunstar Fresh Melon Juice</h3>
                            <div className="flex items-center mb-1">
                                <span className="text-yellow-500 text-sm font-semibold">4.5</span>
                                <svg
                                    className="w-4 h-4 text-yellow-500 ml-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                >
                                    <path d="M10 15l-5.878 3.09 1.122-6.545L0 6.545l6.561-.955L10 0l3.439 5.59L20 6.545l-5.244 4.999 1.122 6.545L10 15z" />
                                </svg>
                            </div>
                            <p className="text-gray-700 font-medium">$18.00</p>
                        </div>

                        {/* Quantity and Add to Cart */}
                        <div className="mt-4 flex items-center">
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-l">
                                -
                            </button>
                            <span className="bg-gray-200 text-gray-700 font-bold py-2 px-4">1</span>
                            <button className="bg-gray-200 text-gray-700 font-bold py-2 px-3 rounded-r">
                                +
                            </button>
                            <button className="ml-auto bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                                Add to Cart
                            </button>
                        </div>
                    </div>
                </div>

            </div>

            {/* fifth page .................... */}

            <section className="py-12">
                <div className="container mx-auto px-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Banner 1 */}
                        <div
                            className="relative bg-red-200 bg-no-repeat bg-right-bottom mb-6 md:mb-0"
                            style={{ backgroundImage: "url('https://www.butlerschocolates.com/upload/637/cms/669809/en/42110/boxed-chocolates.jpg')" }}
                        >
                            <div className="p-8">
                                <div className="text-blue-600 text-3xl font-bold">
                                    Upto 25% Off
                                </div>
                                <h3 className="text-2xl font-semibold mt-2">Luxa Dark Chocolate</h3>
                                <p className="mt-2">
                                    Very tasty &amp; creamy vanilla flavour creamy muffins.
                                </p>
                                <a
                                    href="#"
                                    className="inline-block mt-4 bg-black text-white uppercase px-6 py-3"
                                >
                                    Shop Now
                                </a>
                            </div>
                        </div>

                        {/* Banner 2 */}
                        <div
                            className="relative bg-sky-400 bg-no-repeat bg-right-bottom"
                            style={{ backgroundImage: "url('/images/ad-image-4.png')" }}
                        >
                            <div className="p-8">
                                <div className="text-blue-600 text-3xl font-bold">
                                    Upto 25% Off
                                </div>
                                <h3 className="text-2xl font-semibold mt-2">Creamy Muffins</h3>
                                <p className="mt-2">
                                    Very tasty &amp; creamy vanilla flavour creamy muffins.
                                </p>
                                <a
                                    href="#"
                                    className="inline-block mt-4 bg-black text-white uppercase px-6 py-3"
                                >
                                    Shop Now
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>




        </section>

    );
}

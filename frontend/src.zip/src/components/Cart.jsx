<div className="py-6 px-4 md:px-8 bg-white h-[300px] overflow-hidden">
    <div className="max-w-7xl mx-auto h-full flex flex-col">
        {/* div Header */}
        <div className="flex items-center justify-between mb-4">
            <span className="text-3xl font-bold text-gray-900">Category</span>
            <a href="#" className="text-gray-900 text-lg hover:underline">
                View All →
            </a>
        </div>

        {/* Cards Container */}
        <div className="flex gap-6 flex-wrap">
            {/* CARD 1 */}
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                    alt="Fresh Fruits"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Fruits
                    </h3>
                </div>
            </div>

            {/* CARD 2 */}
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://kidlingoo.com/wp-content/uploads/vegetables_name_in_english_50.jpg"
                    alt="Vegetables"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Vegetables
                    </h3>
                </div>
            </div>

            {/* CARD 3 */}
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://www.wallpics.net/wp-content/uploads/2018/07/Fast-Food-Photos.jpg"
                    alt="Baked"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Baked
                    </h3>
                </div>
            </div>

            {/* CARD 4 */}
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://tse4.mm.bing.net/th/id/OIP.53yAU2iJ5ZSKQwykODu0uAHaEJ?pid=Api&P=0&h=220"
                    alt="Sweets"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Sweets
                    </h3>
                </div>
            </div>
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://wallpaperaccess.com/full/3410682.jpg"
                    alt="Drinks"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Drinks
                    </h3>
                </div>
            </div>
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://kidlingoo.com/wp-content/uploads/vegetables_name_in_english_50.jpg"
                    alt="Vegetables"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Vegetables
                    </h3>
                </div>
            </div>
            <div className="w-40 bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:scale-105 hover:bg-green-50 transition-all duration-300">
                <img
                    src="https://www.wallpics.net/wp-content/uploads/2018/07/Fast-Food-Photos.jpg"
                    alt="Baked"
                    className="w-full h-28 object-cover"
                />
                <div className="p-3">
                    <h3 className="text-lg font-semibold text-gray-800 text-center">
                        Baked
                    </h3>
                </div>
            </div>
        </div>
    </div>
</div>
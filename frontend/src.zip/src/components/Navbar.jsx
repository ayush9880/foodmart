import React from "react";
import { NavLink } from "react-router-dom";
import { FaBars, FaUser, FaHeart, FaShoppingCart } from "react-icons/fa";

export default function Navbar() {
    const cartTotal = 2500; // Example total

    return (
        <header className="border-b flex flex-wrap items-center justify-between p-4 shadow-md">
            {/* Logo & Name */}
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
                <NavLink to="/" className="flex items-center space-x-3">
                    <img
                        src="/foodmart.png"
                        alt="FoodMart Logo"
                        className="h-14 w-14 object-contain"
                    />
                    <div className="leading-tight">
                        <span className="block text-2xl font-bold text-green-600">
                            Food<span className="text-orange-500">Mart</span>
                        </span>
                        <span className="block text-sm text-gray-500">
                            Grocery Store
                        </span>
                    </div>
                </NavLink>
                {/* Mobile hamburger */}
                <button className="text-gray-800 md:hidden">
                    <FaBars size={26} />
                </button>
            </div>

            {/* Category Select */}
            <div className="mb-4 w-full md:mb-0 md:w-auto md:mr-4">
                <select className="border border-gray-300 rounded-lg p-2 shadow-inner w-full md:w-auto">
                    <option value="">All Categories</option>
                    <option value="groceries">Groceries</option>
                    <option value="fruits">Fruits</option>
                    <option value="vegetables">Vegetables</option>
                    <option value="snacks">Snacks</option>
                </select>
            </div>

            {/* Search */}
            <form className="mb-4 w-full md:mb-0 md:w-1/4 relative">
                <input
                    type="text"
                    placeholder="Search for products..."
                    className="bg-gray-100 border-2 border-gray-300 focus:border-orange-500 p-3 pl-10 rounded-lg w-full shadow-inner"
                />
                {/* Search icon inside input */}
                <svg
                    className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 104.35 4.35a7.5 7.5 0 0012.3 12.3z"
                    />
                </svg>
            </form>

            {/* Nav Links & Icons */}
            <nav className="w-full md:w-auto md:flex md:items-center">
                <ul className="flex flex-wrap justify-center md:flex-nowrap md:space-x-6">
                    <li>
                        <NavLink
                            to="/"
                            className="block py-2 px-3 text-gray-700 hover:text-orange-600"
                        >
                            Home
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to="/support"
                            className="block py-2 px-3 text-gray-700 hover:text-orange-600"
                        >
                            For Support? <span className="font-bold">+91-9294805256</span>
                        </NavLink>
                    </li>

                    <li>
                        <NavLink
                            to="/login"
                            className="flex items-center py-2 px-3 text-gray-700 hover:text-orange-600"
                        >
                            <FaUser size={22} className="mr-1" /> Account
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to="/wishlist"
                            className="flex items-center py-2 px-3 text-gray-700 hover:text-orange-600"
                        >
                            <FaHeart size={22} className="mr-1" /> Wishlist
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to="/cart"
                            className="flex items-center py-2 px-3 text-gray-700 hover:text-orange-600"
                        >
                            <FaShoppingCart size={22} className="mr-1" /> ₹{cartTotal}
                        </NavLink>
                    </li>
                </ul>
            </nav>
        </header>
    );
}

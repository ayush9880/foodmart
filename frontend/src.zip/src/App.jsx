import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './components/Navbar'
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import { Route, Routes } from 'react-router-dom'
import LandingPage from './components/LandingPage'
import Cards from './components/ProductCard'
import Login from './components/Login'
import Register from './components/Register'
import Footer from './components/Footer'
import ProductCard from './components/ProductCard'

export default function App() {

  return (

    <><Navbar />
      {/* <LandingPage /> */}
      

      <Routes>
        <Route path="/" element={<LandingPage />}></Route>
        <Route path='/register' element={<Register />}></Route>
        <Route path='/login' element={<Login />}></Route>
        {/* <Route path="/profile" element={<Profile />} /> */}
        {/* <Route path='/forgetPassword' element={<GetOtp />}></Route> */}
        {/* <Route path='/varifyOtp' element={<VerifyOTP />}></Route> */}
        {/* <Route path='/newPassword' element={<NewPassword />}></Route> */}
      </Routes>
      <ToastContainer position="top-center" autoClose={3000} />
      <Footer />
    </>
  )
}


